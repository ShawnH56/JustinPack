# JustinPack

This is a Texture Pack for Minecraft Java 1.16.5

This Texture Pack is in beta, which is why below you will find the things added, not things that need to be added

# Added Textures:

- Wooden Sword
- Stone Sword
- Iron Sword
- Golden Sword
- Diamond Sword

# Features to Be Added

- Bedrock Support
